---
title: "Ozymandius"
tags: ["poem"]
menu: "writing"
date: 2016-10-03
---

Shifting drifts of sand  
Lazily etch their message  
In the old king's plaque.  
 
Words that used to read  
"Upon my works, ye mighty  
Gaze and feel despair!"  
   
Despite my straining,  
All I sense is the endless  
Whisper of the sands.   
