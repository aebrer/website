---
title: "Winter"
tags: ["poem"]
menu: "writing"
date: 2016-10-26
---

No wonder then, that Winter feels so unreal;  
when the trees finally fall to their dreaming,  
leaving the warm-blooded to their feverish movements,  
like scratches of ink on a clean white page.  
