---
title: "Evening Sky"
tags: ["haiku", "poem"]
menu: "writing"
date: 2016-10-03
---

A sliver of moon,  
an airplane's pale cloudy trail;  
hanging in the sky.  
