---
title: "Rainfall"
tags: ["poem"]
menu: "writing"
date: 2016-10-03
---

Gray skies and  
the soft rains fall  
to tear the earth  
and tease the trees  
to struggle for heights.  

Dimly then  
their scent recalls  
in short sweet bursts  
old bitter dreams  
of ancient paradise.  
 
Now alone  
amidst the sounds  
of endless drips  
upon the ground;  
 
remember,  
there is no rest  
and no respite  
but only tired and dim gray light.  
